- [Home](home.md)

- [Layouts](layouts/layout.md)

- Modules
    - [Flash Focus](module/flash.md)
    - [Tabbed](module/tabbed.md)
    - [Tiled Wallpaper](module/twall.md)
    - [Wallpaper Easy Setup](module/wall.md)
    - [Window Swallowing](module/swal.md)
    - [Scratchpad](module/scratch.md)

- Signals
    - [Playerctl](signals/pctl.md)

- Widgets
    - [App Launcher](widgets/app_launcher.md)
    - [Tag Preview](widgets/tag_preview.md)
    - [Task Preview](widgets/task_preview.md)
    - [Tabbed Misc](widgets/tabbed_misc.md)
    - [Window Switcher](widgets/window_switcher.md)

- Extra
    - [Theme Variable Template](theme.md)
