return {
    client = require(... .. ".client"),
    color = require(... .. ".color"),
    filesystem = require(... .. ".filesystem"),
    shape = require(... .. ".shape"),
    time = require(... .. ".time"),
}
