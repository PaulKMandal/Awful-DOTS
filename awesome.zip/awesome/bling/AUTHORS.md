The following developers have contributed major code to bling:

 * [Nooo37](https://github.com/Nooo37)
 * [JavaCafe01](https://github.com/JavaCafe01)
 * [Grumph](https://github.com/Grumph)
 * [Bysmutheye](https://github.com/Bysmutheye)
 * [HumblePresent](https://github.com/HumblePresent)
 * [Kasper24](https://github.com/Kasper24)
 * [undefinedDarkness](https://github.com/undefinedDarkness)
 * [eylles](https://github.com/eylles)
