return {
    playerctl = require(... .. ".playerctl"),
}
