local color = {
  bg_blackest          = "#151520",
  background_dark      = "#1a1b26",
  background_lighter   = "#24283b",
  background_morelight = "#36424c",
  background_lighter2  = "#343b58",
  white                = "#a9b1d6",
  grey                 = "#8389a8",
  blueish_white        = "#89b4fa",
  red                  = "#F7768E",
  green                = "#73daca",
  yellow               = "#E0AF68",
  blue                 = "#7AA2F7",
  magenta              = "#BB9AF7",
  cyan                 = "#7dcfff",

}

return color
