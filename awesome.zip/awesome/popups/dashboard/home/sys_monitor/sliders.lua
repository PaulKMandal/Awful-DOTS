local awful = require("awful")
local gears = require("gears")
local wibox = require("wibox")
local beautiful = require("beautiful")
local dpi = beautiful.xresources.apply_dpi

local color = require("popups.color")

local create_slider = function(slider_values)

end

local ram = {
	name = nil,
	icon = nil,
	total_val_cmd = nil,
	current_val_cmd = nil,
	color = name,

}
