local color = {
  background_dark      = "#1a1b26",
  background_lighter   = "#24283b",
  background_morelight = "#36424c",
  white                = "#a9b1d6",
  blueish_white        = "#89b4fa",
  red                  = "#F7768E",
  green                = "#73daca",
  yellow               = "#E0AF68",
  blue                 = "#7AA2F7",
  magenta              = "#BB9AF7",
  cyan                 = "#7dcfff",

}

return color
